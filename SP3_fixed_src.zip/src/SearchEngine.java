import util.TextUI;

import java.util.ArrayList;

public class SearchEngine {

    TextUI textUI = new TextUI();
    private MediaLibrary mediaLibrary;

    public SearchEngine(MediaLibrary mediaLibrary) {
        this.mediaLibrary = mediaLibrary;
    }

    // Søg på titel
    public void displayTitleSearch() {
        String input = textUI.promptText("Enter title:");
        boolean found = false;
        for (Media media : mediaLibrary.getAllMedia()) {
            if (input.equalsIgnoreCase(media.title)) {
                textUI.displayMsg("You have chosen: " + media.title);
                found = true;
                break;
            }
        }
        if (!found) textUI.displayMsg("Title not found.");
    }

    // Søg på første bogstav
    public ArrayList<Media> searchByFirstLetter(char letter) {
        ArrayList<Media> result = new ArrayList<>();
        for (Media m : mediaLibrary.getAllMedia()) {
            if (Character.toLowerCase(m.title.charAt(0)) == Character.toLowerCase(letter))
                result.add(m);
        }
        return result;
    }

    // Kategori-søgning
    public ArrayList<Media> displayCategorySearch() {
        int categorySelection = selectFromCategoryList("Select a category:") - 1;
        ArrayList<Media> filteredList = new ArrayList<>();
        for (Media media : mediaLibrary.getAllMedia()) {
            for (Category category : media.categories) {
                if (Category.values()[categorySelection].equals(category)) {
                    filteredList.add(media);
                    break;
                }
            }
        }
        return filteredList;
    }

    // Vis filtreret liste og lad bruger vælge
    public void displayFilteredList(ArrayList<Media> filteredList) {
        if (filteredList.isEmpty()) {
            textUI.displayMsg("No titles found in this category.");
            return;
        }
        int mediaSelection = selectFromMediaList("Select a title:", filteredList) - 1;
        textUI.displayMsg("You have chosen: " + filteredList.get(mediaSelection).title);
    }

    private int selectFromMediaList(String message, ArrayList<Media> list) {
        for (int i = 0; i < list.size(); i++)
            message += "\n" + (i + 1) + ". " + list.get(i).toString();
        return textUI.promptNumeric(message);
    }

    private int selectFromCategoryList(String message) {
        Category[] list = Category.values();
        for (int i = 0; i < list.length; i++)
            message += "\n" + (i + 1) + ". " + list[i].toString();
        return textUI.promptNumeric(message);
    }
}
