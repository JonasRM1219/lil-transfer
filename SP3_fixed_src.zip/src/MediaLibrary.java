import util.FileIO;

import java.util.ArrayList;

public class MediaLibrary {

    private ArrayList<Media> allMedia;
    private ArrayList<Media> allSeries;
    private ArrayList<Media> allMovies;
    private SearchEngine searchEngine;

    public MediaLibrary() {
        this.allMedia = new ArrayList<>();
        this.allSeries = new ArrayList<>();
        this.allMovies = new ArrayList<>();
        searchEngine = new SearchEngine(this);
        createMedia();
    }

    public void createMedia() {
        // Film
        ArrayList<String> savedMovies = FileIO.readData("data/movies.csv");
        for (String s : savedMovies) {
            String[] mediaData = s.split(";");
            String title = mediaData[0].trim();
            int releaseYear = Integer.parseInt(mediaData[1].trim());

            ArrayList<Category> categories = new ArrayList<>();
            for (String category : mediaData[2].split(","))
                categories.add(Category.valueOf(category.toLowerCase().trim()));

            double rating = Double.parseDouble(mediaData[3].trim());
            Movie movie = new Movie(title, releaseYear, categories, rating);
            allMedia.add(movie);
            allMovies.add(movie);
        }

        // Serier
        ArrayList<String> savedSeries = FileIO.readData("data/series.csv");
        for (String s : savedSeries) {
            String[] mediaData = s.split(";");
            String title = mediaData[0].trim();
            String releasePeriod = mediaData[1].trim();

            ArrayList<Category> categories = new ArrayList<>();
            for (String category : mediaData[2].split(","))
                categories.add(Category.valueOf(category.toLowerCase().trim()));

            double rating = Double.parseDouble(mediaData[3].trim());
            String[] seasons = mediaData[4].split(",");
            Series series = new Series(title, releasePeriod, categories, rating, seasons);
            allMedia.add(series);
            allSeries.add(series);
        }
    }

    public void displayArray(ArrayList<Media> list) {
        if (list.isEmpty()) {
            System.out.println("Ingen medier fundet.");
        } else {
            for (Media m : list) System.out.println(m.toString());
        }
    }

    public void displayTitleSearch() {
        searchEngine.displayTitleSearch();
    }

    public ArrayList<Media> getAllMedia() { return allMedia; }
    public ArrayList<Media> getAllSeries() { return allSeries; }
    public ArrayList<Media> getAllMovies() { return allMovies; }
    public SearchEngine getSearchEngine() { return searchEngine; }
}
