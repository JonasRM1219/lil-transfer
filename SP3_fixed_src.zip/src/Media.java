import java.util.ArrayList;

public abstract class Media {

    protected String title;
    protected ArrayList<Category> categories;
    protected double rating;

    public Media(String title, ArrayList<Category> categories, double rating) {
        this.title = title;
        this.categories = categories;
        this.rating = rating;
    }

    public String getTitle() {
        return title;
    }

    public double getRating() {
        return rating;
    }

    public ArrayList<Category> getCategories() {
        return categories;
    }

    public abstract void play();

    @Override
    public abstract String toString();
}
