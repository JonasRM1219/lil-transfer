import java.util.ArrayList;

public class Movie extends Media {

    protected int releaseYear;

    public Movie(String title, int releaseYear, ArrayList<Category> categories, double rating) {
        super(title, categories, rating);
        this.releaseYear = releaseYear;
    }

    @Override
    public void play() {
        System.out.println("Playing movie: " + title);
    }

    @Override
    public String toString() {
        return title + " (" + releaseYear + ") - Rating: " + rating;
    }
}
