import util.TextUI;
import java.util.ArrayList;

public class Menu {

    private MediaLibrary mediaLibrary;
    private Service service;
    TextUI ui = new TextUI();

    public Menu(Service service) {
        this.service = service;
        this.mediaLibrary = new MediaLibrary();
    }

    public void mainMenu(User currentUser) {
        while (true) {
            ui.displayMsg("\nWelcome " + currentUser.getUserName());
            ui.displayMsg("=== MENU ===");
            ui.displayMsg("1. Search media");
            ui.displayMsg("2. Show saved lists");
            ui.displayMsg("3. Show all available movies");
            ui.displayMsg("4. Show all available series");
            ui.displayMsg("5. Quit");

            mainMenuOptions(currentUser);
        }
    }

    public void mainMenuOptions(User currentUser) {
        int userInput = ui.promptNumeric("Input choice:");
        switch (userInput) {
            case 1:
                service.searchAndManageMedia();
                break;
            case 2:
                displayListMenu(currentUser);
                break;
            case 3:
                ui.displayMsg("\n--- All Movies ---");
                mediaLibrary.displayArray(mediaLibrary.getAllMovies());
                break;
            case 4:
                ui.displayMsg("\n--- All Series ---");
                mediaLibrary.displayArray(mediaLibrary.getAllSeries());
                break;
            case 5:
                service.saveUsers();
                ui.displayMsg("Goodbye!");
                System.exit(0);
                break;
            default:
                ui.displayMsg("Please pick a valid option (1-5).");
        }
    }

    public void displaySearchMenu() {
        String input = ui.promptText("""
                How do you want to search?
                1. Search by category
                2. Search by title
                3. Back to Main Menu""");
        switch (input) {
            case "1":
                ArrayList<Media> results = mediaLibrary.getSearchEngine().displayCategorySearch();
                mediaLibrary.getSearchEngine().displayFilteredList(results);
                break;
            case "2":
                mediaLibrary.displayTitleSearch();
                break;
            case "3":
                break;
            default:
                ui.displayMsg("Please pick a valid option (1-3).");
                displaySearchMenu();
        }
    }

    public void displayListMenu(User currentUser) {
        String userInput = ui.promptText("""
                Which list would you like to view?
                
                 1. Want to watch
                
                 2. Watched
                
                 3. Back to Main Menu""");
        switch (userInput) {
            case "1":
                displayList(currentUser.getWantToWatch());
                break;
            case "2":
                displayList(currentUser.getWatched());
                break;
            case "3":
                break;
            default:
                ui.displayMsg("Please pick a valid option (1-3).");
        }
    }

    public void displayList(ArrayList<String> list) {
        if (list.isEmpty()) {
            ui.displayMsg("Listen er tom.");
        } else {
            for (String s : list) ui.displayMsg(s);
        }
    }

    public MediaLibrary getMediaLibrary() {
        return this.mediaLibrary;
    }
}
