import util.FileIO;
import util.TextUI;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Service {

    private MediaLibrary mediaLibrary;
    private User currentUser;
    private ArrayList<User> brugere = new ArrayList<>();
    private final Scanner scanner = new Scanner(System.in);
    TextUI ui = new TextUI();

    public Service() {
        loadBrugere();
        mediaLibrary = new MediaLibrary();
    }

    // Indlæs alle brugere fra CSV ved opstart
    private void loadBrugere() {
        ArrayList<String> userData = FileIO.readData("data/userData.csv");
        for (String line : userData) {
            String[] data = line.split(";");
            if (data.length >= 2) {
                String navn = data[0].trim();
                String pass = data[1].trim();
                ArrayList<String> want = new ArrayList<>();
                ArrayList<String> watched = new ArrayList<>();
                if (data.length >= 4) {
                    if (!data[2].trim().isEmpty())
                        for (String s : data[2].split(",")) want.add(s.trim());
                    if (!data[3].trim().isEmpty())
                        for (String s : data[3].split(",")) watched.add(s.trim());
                }
                brugere.add(new User(navn, pass, want, watched));
            }
        }
    }

    // ---- SØG OG ADMINISTRER WANT TO WATCH ----
    public void searchAndManageMedia() {
        ui.displayMsg("\n=== SØG EFTER MEDIA ===");
        String input = ui.promptText("Indtast titel (eller del af titel):");

        ArrayList<Media> results = new ArrayList<>();
        for (Media m : mediaLibrary.getAllMedia()) {
            if (m.getTitle().toLowerCase().contains(input.toLowerCase()))
                results.add(m);
        }

        if (results.isEmpty()) {
            ui.displayMsg("Ingen resultater fundet for: " + input);
            return;
        }

        // Vis resultater med markering hvis allerede i want to watch
        ui.displayMsg("\nResultater:");
        for (int i = 0; i < results.size(); i++) {
            String marker = currentUser.getWantToWatch().contains(results.get(i).getTitle()) ? " [★ Want to Watch]" : "";
            ui.displayMsg((i + 1) + ". " + results.get(i).toString() + marker);
        }

        int valg = ui.promptNumeric("Vælg et nummer (0 for at gå tilbage):") - 1;
        if (valg < 0 || valg >= results.size()) return;

        manageWantToWatch(results.get(valg));
    }

    // Tilføj eller fjern fra want to watch
    private void manageWantToWatch(Media media) {
        String titel = media.getTitle();
        boolean erIListe = currentUser.getWantToWatch().contains(titel);

        ui.displayMsg("\nValgt: " + titel);

        if (erIListe) {
            ui.displayMsg("Dette medie er allerede i din Want to Watch liste.");
            String svar = ui.promptText("Vil du fjerne det? (ja/nej):");
            if (svar.trim().equalsIgnoreCase("ja")) {
                currentUser.getWantToWatch().remove(titel);
                ui.displayMsg("\"" + titel + "\" er fjernet fra din Want to Watch liste.");
                saveUsers();
            }
        } else {
            ui.displayMsg("Dette medie er ikke i din Want to Watch liste.");
            String svar = ui.promptText("Vil du tilføje det? (ja/nej):");
            if (svar.trim().equalsIgnoreCase("ja")) {
                currentUser.getWantToWatch().add(titel);
                ui.displayMsg("\"" + titel + "\" er tilføjet til din Want to Watch liste.");
                saveUsers();
            }
        }
    }

    // Gem alle brugere til CSV
    public void saveUsers() {
        ArrayList<String> lines = new ArrayList<>();
        for (User u : brugere) {
            String want = String.join(",", u.getWantToWatch());
            String watched = String.join(",", u.getWatched());
            lines.add(u.getUserName() + ";" + u.getPassWord() + ";" + want + ";" + watched);
        }
        FileIO.saveData(lines, "data/userData.csv");
    }

    // ---- LOGIN PROMPT ----
    public void loginPrompt() {
        System.out.println("\nSTREAMINGCHILL");

        while (true) {
            System.out.print("\nHar du allerede en bruger? (ja/nej): ");
            String svar = scanner.nextLine().trim().toLowerCase();

            if (svar.equals("ja")) {
                login();
                break;
            } else if (svar.equals("nej")) {
                opretBruger();
                break;
            } else {
                System.out.println("Skriv 'ja' eller 'nej'.");
            }
        }

        Menu menu = new Menu(this);
        menu.mainMenu(currentUser);
    }

    // ---- LOGIN ----
    public void login() {
        while (true) {
            System.out.print("\nBrugernavn: ");
            String navn = scanner.nextLine();
            System.out.print("Adgangskode: ");
            String pass = scanner.nextLine();

            User matchedUser = null;
            for (User u : brugere) {
                if (u.getUserName().equals(navn) && u.getPassWord().equals(pass)) {
                    matchedUser = u;
                    break;
                }
            }

            if (matchedUser != null) {
                currentUser = matchedUser;
                System.out.println("\nVELKOMMEN " + navn.toUpperCase() + "!");
                System.out.println("Du er nu logget ind.");
                return;
            } else {
                System.out.println("\nLOGIN FEJLEDE! Forkert brugernavn eller adgangskode.");
                System.out.print("Har du ikke en bruger? (ja/nej): ");
                String svar = scanner.nextLine().trim().toLowerCase();
                if (svar.equals("ja")) {
                    opretBruger();
                    return;
                }
                System.out.println("Prøver igen...");
            }
        }
    }

    // ---- OPRET BRUGER ----
    public void opretBruger() {
        while (true) {
            System.out.print("\nVælg brugernavn: ");
            String navn = scanner.nextLine();

            boolean taget = false;
            for (User u : brugere) {
                if (u.getUserName().equals(navn)) {
                    System.out.println("Brugernavn er allerede taget!");
                    taget = true;
                    break;
                }
            }
            if (taget) continue;

            System.out.print("Vælg adgangskode: ");
            String pass = scanner.nextLine();
            System.out.print("Bekræft adgangskode: ");
            String bekraeft = scanner.nextLine();

            if (!pass.equals(bekraeft)) {
                System.out.println("Adgangskoder matcher ikke!");
                continue;
            }

            User nyBruger = new User(navn, pass, new ArrayList<>(), new ArrayList<>());
            brugere.add(nyBruger);

            try (FileWriter writer = new FileWriter("data/userData.csv", true)) {
                writer.write(navn + ";" + pass + ";;\n");
            } catch (IOException e) {
                System.out.println("Fejl ved gemning af bruger.");
            }

            currentUser = nyBruger;
            System.out.println("\nBruger oprettet!");
            System.out.println("VELKOMMEN " + navn.toUpperCase() + "!");
            return;
        }
    }

    // ---- GETTERS ----
    public User getCurrentUser() { return currentUser; }
    public ArrayList<User> getBrugere() { return brugere; }
    public MediaLibrary getMediaLibrary() { return mediaLibrary; }

    public String printCurrentUser() {
        return "currentUser=" + currentUser.getUserName() + "}" +
                "password=" + currentUser.getPassWord() + "}" +
                "want to watch=" + currentUser.printWantToWatch() + "}" +
                "watched=" + currentUser.printWatched() + "}";
    }

    void createExistingUser(String userName) {
        String[] attribute = getUserData(userName);
        if (attribute == null) return;

        ArrayList<String> wantToWatch = new ArrayList<>();
        if (attribute.length > 2 && !attribute[2].trim().isEmpty())
            for (String s : attribute[2].split(",")) wantToWatch.add(s.trim());

        ArrayList<String> watched = new ArrayList<>();
        if (attribute.length > 3 && !attribute[3].trim().isEmpty())
            for (String t : attribute[3].split(",")) watched.add(t.trim());

        User u = new User(attribute[0].trim(), attribute[1].trim(), wantToWatch, watched);
        currentUser = u;
        brugere.add(u);
    }

    public String[] getUserData(String username) {
        ArrayList<String> userData = FileIO.readData("data/userData.csv");
        for (String line : userData) {
            String[] attributes = line.split(";");
            if (username.equals(attributes[0].trim())) return line.split(";");
        }
        return null;
    }

    public ArrayList<String> getExistingUPs() {
        ArrayList<String> UPs = new ArrayList<>();
        for (User u : brugere) UPs.add(u.getUserName() + ", " + u.getPassWord());
        return UPs;
    }
}
